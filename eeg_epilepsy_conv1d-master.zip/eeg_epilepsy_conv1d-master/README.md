eeg_epilepsy_conv1d

Based off of https://arxiv.org/pdf/1801.05412.pdf

